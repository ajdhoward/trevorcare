# AI review bundle (sample)

Depersonalised sample data for the Family Care Hub.
Start with insights/*.json (small, high-signal), then request specific CSV extracts.
Every file is synthetic; replace with your own export for a real review.
